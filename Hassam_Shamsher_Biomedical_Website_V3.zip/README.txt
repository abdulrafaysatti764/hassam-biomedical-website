HASSAM SHAMSHER - BIOMEDICAL WEBSITE V3

This version intentionally DOES NOT include:
- Education / qualification
- Work experience
- Companies worked for
- Years of experience
- CV-style timeline

It uses only:
- Name: Hassam Shamsher
- Designation: Biomedical Engineer
- Professional medical/laboratory website content

HOW TO VIEW:
1. Download the ZIP.
2. Extract it.
3. Open index.html in Chrome.
4. The complete design is inside one HTML file.

To publish later, upload index.html to a static web host.
